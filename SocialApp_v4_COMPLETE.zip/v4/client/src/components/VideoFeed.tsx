import { useState, useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import VideoCard from "./VideoCard";
import { Spinner } from "@/components/ui/spinner";

interface VideoFeedProps {
  category: "explore" | "following" | "recommended";
}

export default function VideoFeed({ category }: VideoFeedProps) {
  const { isAuthenticated } = useAuth();
  const [offset, setOffset] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);

  // Fetch videos based on category
  const videosQuery = isAuthenticated && category === "following"
    ? trpc.videos.getFollowingVideos.useQuery({ limit: 20, offset })
    : trpc.videos.getByCategory.useQuery({ category, limit: 20, offset });

  const { data: videos = [], isLoading } = videosQuery;

  // Handle scroll to load more videos
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      if (scrollHeight - scrollTop - clientHeight < 500) {
        setOffset((prev) => prev + 20);
      }
    };

    container.addEventListener("scroll", handleScroll);
    return () => container.removeEventListener("scroll", handleScroll);
  }, []);

  if (isLoading && videos.length === 0) {
    return (
      <div className="h-full flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  if (videos.length === 0) {
    return (
      <div className="h-full flex items-center justify-center">
        <p className="text-muted-foreground">ไม่มีวิดีโอในขณะนี้</p>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="h-full overflow-y-scroll snap-y snap-mandatory scroll-smooth"
    >
      <div className="flex flex-col">
        {videos.map((video, index) => (
          <div
            key={video.id}
            className="h-screen w-full snap-start flex-shrink-0 relative"
          >
            <VideoCard
              video={video}
              isActive={index === currentVideoIndex}
              onView={() => setCurrentVideoIndex(index)}
            />
          </div>
        ))}
      </div>

      {isLoading && videos.length > 0 && (
        <div className="h-screen flex items-center justify-center">
          <Spinner />
        </div>
      )}
    </div>
  );
}
