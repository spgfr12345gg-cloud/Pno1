import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Share2,
  Copy,
  Mail,
  MessageCircle,
  Link as LinkIcon,
  X,
} from "lucide-react";
import { toast } from "sonner";

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoTitle: string;
  videoUrl: string;
}

export default function ShareModal({
  isOpen,
  onClose,
  videoTitle,
  videoUrl,
}: ShareModalProps) {
  const [copied, setCopied] = useState(false);

  const shareUrl = `${window.location.origin}${videoUrl}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    toast.success("คัดลอกลิงก์แล้ว");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareVia = (method: string) => {
    let url = "";
    const text = `${videoTitle} - ${shareUrl}`;

    switch (method) {
      case "facebook":
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
        break;
      case "twitter":
        url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`;
        break;
      case "whatsapp":
        url = `https://wa.me/?text=${encodeURIComponent(text)}`;
        break;
      case "email":
        url = `mailto:?subject=${encodeURIComponent(videoTitle)}&body=${encodeURIComponent(text)}`;
        break;
      case "line":
        url = `https://line.me/R/msg/0/?${encodeURIComponent(text)}`;
        break;
    }

    if (url) {
      window.open(url, "_blank");
      toast.success("เปิดแอปแชร์แล้ว");
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            แชร์วิดีโอ
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Copy Link Section */}
          <div className="space-y-2">
            <label className="text-sm font-medium">คัดลอกลิงก์</label>
            <div className="flex gap-2">
              <Input
                value={shareUrl}
                readOnly
                className="text-xs"
              />
              <Button
                size="sm"
                onClick={handleCopyLink}
                className={copied ? "bg-green-500 hover:bg-green-600" : ""}
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Share Via Section */}
          <div className="space-y-2">
            <label className="text-sm font-medium">แชร์ผ่าน</label>
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleShareVia("facebook")}
                className="gap-2"
              >
                <Share2 className="w-4 h-4" />
                Facebook
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleShareVia("twitter")}
                className="gap-2"
              >
                <Share2 className="w-4 h-4" />
                Twitter
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleShareVia("whatsapp")}
                className="gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleShareVia("line")}
                className="gap-2"
              >
                <Share2 className="w-4 h-4" />
                LINE
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleShareVia("email")}
                className="gap-2"
              >
                <Mail className="w-4 h-4" />
                Email
              </Button>
            </div>
          </div>

          {/* Close Button */}
          <Button
            variant="outline"
            className="w-full"
            onClick={onClose}
          >
            ปิด
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
