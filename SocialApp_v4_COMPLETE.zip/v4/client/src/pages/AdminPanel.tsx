import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Users, Video, Heart, UserPlus, ShieldCheck, Ban,
  Trash2, Plus, Search, BarChart3, CheckCircle, XCircle,
  ChevronLeft, Eye, Star, Ghost
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Tab = "stats" | "users" | "videos" | "fake";

export default function AdminPanel() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [tab, setTab] = useState<Tab>("stats");
  const [userSearch, setUserSearch] = useState("");
  const [videoSearch, setVideoSearch] = useState("");

  // ป้องกัน non-admin
  if (!user || user.role !== "admin") {
    return (
      <div className="flex flex-col items-center justify-center h-screen gap-3">
        <ShieldCheck className="w-16 h-16 text-red-400" />
        <p className="font-bold text-lg">ไม่มีสิทธิ์เข้าถึง</p>
        <Button onClick={() => navigate("/")}>กลับหน้าแรก</Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-950 text-white">
      {/* Header */}
      <div className="bg-gray-900 border-b border-gray-800 px-4 py-3 flex items-center gap-3 sticky top-0 z-50">
        <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="text-gray-400 hover:text-white rounded-full">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="font-bold text-lg">🛡️ Admin Panel</h1>
          <p className="text-xs text-gray-400">จัดการโดย {user.name}</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex bg-gray-900 border-b border-gray-800 overflow-x-auto">
        {([
          { id: "stats", label: "📊 ภาพรวม", icon: BarChart3 },
          { id: "users", label: "👥 ผู้ใช้", icon: Users },
          { id: "videos", label: "🎬 วิดีโอ", icon: Video },
          { id: "fake", label: "👻 บัญชีปลอม", icon: Ghost },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
              tab === t.id ? "border-blue-500 text-blue-400" : "border-transparent text-gray-400 hover:text-white"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {tab === "stats" && <StatsTab />}
        {tab === "users" && <UsersTab search={userSearch} setSearch={setUserSearch} />}
        {tab === "videos" && <VideosTab search={videoSearch} setSearch={setVideoSearch} />}
        {tab === "fake" && <FakeTab />}
      </div>
    </div>
  );
}

// ── Stats Tab ──────────────────────────────────────────
function StatsTab() {
  const { data: stats, isLoading } = trpc.admin.getStats.useQuery();

  if (isLoading) return <div className="flex justify-center py-20"><div className="animate-spin w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full" /></div>;

  const cards = [
    { label: "ผู้ใช้ทั้งหมด", value: stats?.totalUsers ?? 0, icon: "👥", color: "blue" },
    { label: "วิดีโอทั้งหมด", value: stats?.totalVideos ?? 0, icon: "🎬", color: "purple" },
    { label: "ไลค์ทั้งหมด", value: stats?.totalLikes ?? 0, icon: "❤️", color: "red" },
    { label: "การติดตาม", value: stats?.totalFollows ?? 0, icon: "👤", color: "green" },
    { label: "ถูกแบน", value: stats?.bannedUsers ?? 0, icon: "🚫", color: "orange" },
    { label: "บัญชีปลอม", value: stats?.fakeUsers ?? 0, icon: "👻", color: "gray" },
  ];

  return (
    <div className="p-4 grid grid-cols-2 gap-3">
      {cards.map((c) => (
        <div key={c.label} className="bg-gray-800 rounded-2xl p-4 border border-gray-700">
          <div className="text-2xl mb-2">{c.icon}</div>
          <div className="text-2xl font-bold">{c.value.toLocaleString()}</div>
          <div className="text-xs text-gray-400 mt-1">{c.label}</div>
        </div>
      ))}
    </div>
  );
}

// ── Users Tab ──────────────────────────────────────────
function UsersTab({ search, setSearch }: { search: string; setSearch: (s: string) => void }) {
  const utils = trpc.useUtils();
  const { data: allUsers = [], isLoading } = trpc.admin.getAllUsers.useQuery({ limit: 100 });

  const setVerified = trpc.admin.setVerified.useMutation({ onSuccess: () => { utils.admin.getAllUsers.invalidate(); toast.success("อัปเดตแล้ว"); } });
  const setBanned = trpc.admin.setBanned.useMutation({ onSuccess: () => { utils.admin.getAllUsers.invalidate(); toast.success("อัปเดตแล้ว"); } });
  const deleteUser = trpc.admin.deleteUser.useMutation({ onSuccess: () => { utils.admin.getAllUsers.invalidate(); toast.success("ลบผู้ใช้แล้ว"); } });
  const addFollowers = trpc.admin.addFakeFollowers.useMutation({ onSuccess: (d) => toast.success(`เพิ่ม ${d.added} ผู้ติดตามแล้ว`) });

  const filtered = allUsers.filter(u =>
    !search || u.name?.toLowerCase().includes(search.toLowerCase()) || u.email?.toLowerCase().includes(search.toLowerCase())
  );

  const handleDelete = (userId: number, name: string) => {
    if (confirm(`ลบบัญชี "${name}" ถาวร?`)) deleteUser.mutate({ userId });
  };

  return (
    <div className="p-4 space-y-3">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="ค้นหาผู้ใช้..." className="pl-10 bg-gray-800 border-gray-700 text-white rounded-xl" />
      </div>

      {isLoading ? (
        <div className="flex justify-center py-10"><div className="animate-spin w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full" /></div>
      ) : filtered.map((u) => (
        <div key={u.id} className="bg-gray-800 rounded-2xl p-4 border border-gray-700 space-y-3">
          {/* User Info */}
          <div className="flex items-center gap-3">
            {u.profileImageUrl
              ? <img src={u.profileImageUrl} className="w-12 h-12 rounded-full object-cover" alt={u.name||""} />
              : <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center font-bold text-lg">{(u.name||"?")[0]}</div>
            }
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-semibold truncate">{u.name || "ไม่มีชื่อ"}</span>
                {u.isVerified && <span title="Verified">✅</span>}
                {u.isBanned && <span className="text-xs bg-red-900 text-red-300 px-2 py-0.5 rounded-full">แบน</span>}
                {u.isFake && <span className="text-xs bg-gray-700 text-gray-300 px-2 py-0.5 rounded-full">ปลอม</span>}
                {u.role === "admin" && <span className="text-xs bg-yellow-900 text-yellow-300 px-2 py-0.5 rounded-full">Admin</span>}
              </div>
              <div className="text-xs text-gray-400 truncate">{u.email || u.openId}</div>
              <div className="text-xs text-gray-500">ผู้ติดตาม: {(u.followerCount||0).toLocaleString()}</div>
            </div>
          </div>

          {/* Actions */}
          <div className="grid grid-cols-2 gap-2">
            <Button
              size="sm"
              variant={u.isVerified ? "destructive" : "outline"}
              onClick={() => setVerified.mutate({ userId: u.id, isVerified: !u.isVerified })}
              className="text-xs rounded-xl"
              disabled={u.role === "admin"}
            >
              {u.isVerified ? "✅ ถอด Verified" : "✅ ให้ Verified"}
            </Button>
            <Button
              size="sm"
              variant={u.isBanned ? "outline" : "destructive"}
              onClick={() => setBanned.mutate({ userId: u.id, isBanned: !u.isBanned })}
              className="text-xs rounded-xl"
              disabled={u.role === "admin"}
            >
              <Ban className="w-3 h-3 mr-1" />
              {u.isBanned ? "ปลดแบน" : "แบน"}
            </Button>
            <Button
              size="sm" variant="outline"
              onClick={() => { const n = prompt("เพิ่มผู้ติดตามกี่คน?", "10"); if (n) addFollowers.mutate({ targetUserId: u.id, count: parseInt(n) }); }}
              className="text-xs rounded-xl border-blue-800 text-blue-400 hover:bg-blue-900/30"
            >
              <UserPlus className="w-3 h-3 mr-1" /> เพิ่มผู้ติดตาม
            </Button>
            <Button
              size="sm" variant="outline"
              onClick={() => handleDelete(u.id, u.name || "")}
              className="text-xs rounded-xl border-red-800 text-red-400 hover:bg-red-900/30"
              disabled={u.role === "admin"}
            >
              <Trash2 className="w-3 h-3 mr-1" /> ลบบัญชี
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Videos Tab ─────────────────────────────────────────
function VideosTab({ search, setSearch }: { search: string; setSearch: (s: string) => void }) {
  const utils = trpc.useUtils();
  const { data: allVideos = [], isLoading } = trpc.admin.getAllVideos.useQuery({ limit: 100 });
  const deleteVideo = trpc.admin.deleteVideo.useMutation({ onSuccess: () => { utils.admin.getAllVideos.invalidate(); toast.success("ลบวิดีโอแล้ว"); } });
  const addLikes = trpc.admin.addFakeLikes.useMutation({ onSuccess: () => toast.success("เพิ่มไลค์แล้ว") });

  const filtered = allVideos.filter(v =>
    !search || v.title?.toLowerCase().includes(search.toLowerCase()) || v.hashtags?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 space-y-3">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="ค้นหาวิดีโอ..." className="pl-10 bg-gray-800 border-gray-700 text-white rounded-xl" />
      </div>

      {isLoading ? (
        <div className="flex justify-center py-10"><div className="animate-spin w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full" /></div>
      ) : filtered.map((v) => (
        <div key={v.id} className={`bg-gray-800 rounded-2xl p-4 border space-y-3 ${v.isDeleted ? "border-red-900 opacity-50" : "border-gray-700"}`}>
          <div className="flex gap-3">
            {v.thumbnailUrl
              ? <img src={v.thumbnailUrl} className="w-16 h-16 rounded-xl object-cover flex-shrink-0" alt="" />
              : <div className="w-16 h-16 rounded-xl bg-gray-700 flex items-center justify-center flex-shrink-0"><Video className="w-6 h-6 text-gray-500" /></div>
            }
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm truncate">{v.title || "ไม่มีชื่อ"}</p>
              <p className="text-xs text-gray-400 truncate">{v.hashtags}</p>
              <div className="flex gap-3 mt-1 text-xs text-gray-400">
                <span>👁 {(v.viewCount||0).toLocaleString()}</span>
                <span>❤️ {(v.likeCount||0).toLocaleString()}</span>
                <span>💬 {(v.commentCount||0).toLocaleString()}</span>
              </div>
              {v.isDeleted && <span className="text-xs text-red-400">ถูกลบแล้ว</span>}
            </div>
          </div>

          {!v.isDeleted && (
            <div className="flex gap-2">
              <Button size="sm" variant="outline"
                onClick={() => { const n = prompt("เพิ่มไลค์กี่ไลค์?", "10"); if (n) addLikes.mutate({ videoId: v.id, count: parseInt(n) }); }}
                className="flex-1 text-xs rounded-xl border-pink-800 text-pink-400 hover:bg-pink-900/30"
              >
                ❤️ เพิ่มไลค์
              </Button>
              <Button size="sm" variant="outline"
                onClick={() => { if (confirm(`ลบวิดีโอ "${v.title}"?`)) deleteVideo.mutate({ videoId: v.id }); }}
                className="flex-1 text-xs rounded-xl border-red-800 text-red-400 hover:bg-red-900/30"
              >
                <Trash2 className="w-3 h-3 mr-1" /> ลบวิดีโอ
              </Button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ── Fake Accounts Tab ──────────────────────────────────
function FakeTab() {
  const utils = trpc.useUtils();
  const [name, setName] = useState("");
  const [bio, setBio] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [targetUserId, setTargetUserId] = useState("");
  const [followCount, setFollowCount] = useState("10");

  const createFake = trpc.admin.createFakeUser.useMutation({
    onSuccess: () => { toast.success("สร้างบัญชีปลอมแล้ว ✅"); setName(""); setBio(""); setPhotoUrl(""); utils.admin.getAllUsers.invalidate(); },
  });
  const addFollowers = trpc.admin.addFakeFollowers.useMutation({
    onSuccess: (d) => toast.success(`เพิ่ม ${d.added} ผู้ติดตามแล้ว ✅`),
  });

  const { data: fakeUsers = [] } = trpc.admin.getAllUsers.useQuery({ limit: 200 });
  const fakeList = fakeUsers.filter(u => u.isFake);

  return (
    <div className="p-4 space-y-5">
      {/* สร้างบัญชีปลอม */}
      <div className="bg-gray-800 rounded-2xl p-4 border border-gray-700 space-y-3">
        <h2 className="font-bold flex items-center gap-2"><Ghost className="w-5 h-5" /> สร้างบัญชีปลอม</h2>
        <Input value={name} onChange={e => setName(e.target.value)} placeholder="ชื่อบัญชีปลอม *" className="bg-gray-700 border-gray-600 rounded-xl text-white" />
        <Input value={bio} onChange={e => setBio(e.target.value)} placeholder="ประวัติ (ไม่บังคับ)" className="bg-gray-700 border-gray-600 rounded-xl text-white" />
        <Input value={photoUrl} onChange={e => setPhotoUrl(e.target.value)} placeholder="URL รูปโปรไฟล์ (ไม่บังคับ)" className="bg-gray-700 border-gray-600 rounded-xl text-white" />
        <Button className="w-full rounded-xl" onClick={() => { if (!name.trim()) { toast.error("ใส่ชื่อก่อน"); return; } createFake.mutate({ name: name.trim(), bio: bio.trim(), profileImageUrl: photoUrl.trim() || undefined }); }} disabled={createFake.isPending}>
          <Plus className="w-4 h-4 mr-2" /> {createFake.isPending ? "กำลังสร้าง..." : "สร้างบัญชีปลอม"}
        </Button>
      </div>

      {/* เพิ่มผู้ติดตามให้ช่อง */}
      <div className="bg-gray-800 rounded-2xl p-4 border border-gray-700 space-y-3">
        <h2 className="font-bold flex items-center gap-2"><UserPlus className="w-5 h-5" /> เพิ่มผู้ติดตามให้ช่อง</h2>
        <Input value={targetUserId} onChange={e => setTargetUserId(e.target.value)} placeholder="User ID ช่องที่ต้องการ" type="number" className="bg-gray-700 border-gray-600 rounded-xl text-white" />
        <Input value={followCount} onChange={e => setFollowCount(e.target.value)} placeholder="จำนวนผู้ติดตาม" type="number" min="1" max="500" className="bg-gray-700 border-gray-600 rounded-xl text-white" />
        <p className="text-xs text-gray-400">บัญชีปลอมที่มี: {fakeList.length} บัญชี</p>
        <Button className="w-full rounded-xl bg-blue-600 hover:bg-blue-700"
          onClick={() => {
            if (!targetUserId) { toast.error("ใส่ User ID ก่อน"); return; }
            if (fakeList.length === 0) { toast.error("ยังไม่มีบัญชีปลอม สร้างก่อน"); return; }
            addFollowers.mutate({ targetUserId: parseInt(targetUserId), count: parseInt(followCount) });
          }}
          disabled={addFollowers.isPending}
        >
          <UserPlus className="w-4 h-4 mr-2" /> {addFollowers.isPending ? "กำลังเพิ่ม..." : "เพิ่มผู้ติดตาม"}
        </Button>
      </div>

      {/* รายการบัญชีปลอม */}
      {fakeList.length > 0 && (
        <div className="bg-gray-800 rounded-2xl p-4 border border-gray-700">
          <h2 className="font-bold mb-3">รายการบัญชีปลอม ({fakeList.length})</h2>
          <div className="space-y-2">
            {fakeList.map(u => (
              <div key={u.id} className="flex items-center gap-3 p-2 bg-gray-700/50 rounded-xl">
                {u.profileImageUrl
                  ? <img src={u.profileImageUrl} className="w-9 h-9 rounded-full object-cover" alt="" />
                  : <div className="w-9 h-9 rounded-full bg-gray-600 flex items-center justify-center text-sm font-bold">{(u.name||"?")[0]}</div>
                }
                <div>
                  <p className="text-sm font-medium">{u.name}</p>
                  <p className="text-xs text-gray-400">ID: {u.id} · ผู้ติดตาม: {(u.followerCount||0).toLocaleString()}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
