import { useState, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ChevronLeft, Camera, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

export default function Settings() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("account");

  const utils = trpc.useUtils();

  // ข้อมูลโปรไฟล์
  const [name, setName] = useState(user?.name || "");
  const [bio, setBio] = useState(user?.bio || "");
  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);

  // การแจ้งเตือน
  const [notifyLikes, setNotifyLikes] = useState(true);
  const [notifyComments, setNotifyComments] = useState(true);
  const [notifyFollows, setNotifyFollows] = useState(true);
  const [notifyReposts, setNotifyReposts] = useState(true);

  // วิดีโอ
  const [autoPlay, setAutoPlay] = useState(true);
  const [videoQuality, setVideoQuality] = useState("auto");
  const [wifiOnly, setWifiOnly] = useState(false);

  // ความเป็นส่วนตัว
  const [privateAccount, setPrivateAccount] = useState(false);
  const [allowComments, setAllowComments] = useState(true);

  const updateProfileMutation = trpc.users.updateProfile.useMutation({
    onSuccess: () => {
      utils.auth.me.invalidate();
      toast.success("บันทึกโปรไฟล์แล้ว ✅");
      setIsSaving(false);
    },
    onError: () => {
      toast.error("เกิดข้อผิดพลาด กรุณาลองใหม่");
      setIsSaving(false);
    },
  });

  // เปลี่ยนรูปโปรไฟล์
  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("กรุณาเลือกไฟล์รูปภาพ"); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error("รูปภาพต้องไม่เกิน 5MB"); return; }

    setIsUploadingPhoto(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("type", "image");
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      if (!res.ok) throw new Error();
      const { url } = await res.json();
      await updateProfileMutation.mutateAsync({ profileImageUrl: url });
      toast.success("เปลี่ยนรูปโปรไฟล์แล้ว 📸");
    } catch {
      toast.error("อัปโหลดรูปไม่สำเร็จ");
    } finally {
      setIsUploadingPhoto(false);
      if (photoInputRef.current) photoInputRef.current.value = "";
    }
  };

  // บันทึกโปรไฟล์
  const handleSaveProfile = async () => {
    if (!name.trim()) { toast.error("กรุณาใส่ชื่อ"); return; }
    setIsSaving(true);
    await updateProfileMutation.mutateAsync({ name: name.trim(), bio: bio.trim() });
  };

  const handleDeleteAccount = () => {
    if (window.confirm("คุณแน่ใจหรือว่าต้องการลบบัญชี? การกระทำนี้ไม่สามารถยกเลิกได้")) {
      toast.info("ฟีเจอร์นี้กำลังพัฒนา");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background border-b border-border px-4 py-3 flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={() => navigate("/profile")} className="rounded-full">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h1 className="font-bold text-lg">ตั้งค่า</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full justify-start rounded-none border-b border-border px-2 bg-background overflow-x-auto flex h-11 gap-1">
          {["account","notifications","privacy","video","general"].map((tab) => (
            <TabsTrigger key={tab} value={tab} className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent data-[state=active]:text-accent text-xs px-3">
              {tab === "account" ? "บัญชี"
                : tab === "notifications" ? "แจ้งเตือน"
                : tab === "privacy" ? "ความเป็นส่วนตัว"
                : tab === "video" ? "วิดีโอ"
                : "ทั่วไป"}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* ── บัญชี ── */}
        <TabsContent value="account" className="p-4 space-y-5">
          {/* รูปโปรไฟล์ */}
          <div className="flex flex-col items-center gap-3 py-2">
            <div className="relative">
              {user?.profileImageUrl ? (
                <img src={user.profileImageUrl} alt="โปรไฟล์" className="w-24 h-24 rounded-full object-cover border-2 border-accent/30" />
              ) : (
                <div className="w-24 h-24 rounded-full bg-accent flex items-center justify-center text-3xl font-bold text-accent-foreground">
                  {(user?.name || "ผ")[0]}
                </div>
              )}
              <button
                onClick={() => photoInputRef.current?.click()}
                disabled={isUploadingPhoto}
                className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-accent flex items-center justify-center shadow-lg hover:opacity-90"
              >
                {isUploadingPhoto
                  ? <Loader2 className="w-4 h-4 text-white animate-spin" />
                  : <Camera className="w-4 h-4 text-accent-foreground" />
                }
              </button>
            </div>
            <button onClick={() => photoInputRef.current?.click()} className="text-sm text-accent font-medium">
              เปลี่ยนรูปโปรไฟล์
            </button>
            <input ref={photoInputRef} type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" />
          </div>

          {/* ชื่อ */}
          <div>
            <Label htmlFor="name">ชื่อ</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="ชื่อของคุณ" className="mt-2 rounded-xl" maxLength={50} />
          </div>

          {/* ประวัติ */}
          <div>
            <Label htmlFor="bio">ประวัติส่วนตัว</Label>
            <Textarea id="bio" value={bio} onChange={(e) => setBio(e.target.value)} placeholder="เขียนเกี่ยวกับตัวคุณ..." className="mt-2 rounded-xl resize-none" rows={3} maxLength={200} />
            <p className="text-xs text-muted-foreground text-right mt-1">{bio.length}/200</p>
          </div>

          <Button onClick={handleSaveProfile} className="w-full rounded-xl h-11" disabled={isSaving}>
            {isSaving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> กำลังบันทึก...</> : "บันทึกการเปลี่ยนแปลง"}
          </Button>

          <div className="pt-4 border-t border-border">
            <Button variant="destructive" className="w-full rounded-xl" onClick={handleDeleteAccount}>
              <Trash2 className="w-4 h-4 mr-2" /> ลบบัญชี
            </Button>
          </div>
        </TabsContent>

        {/* ── การแจ้งเตือน ── */}
        <TabsContent value="notifications" className="p-4 space-y-4">
          {[
            { label: "แจ้งเตือนเมื่อมีคนกดใจ ❤️", desc: "เมื่อมีคนถูกใจวิดีโอของคุณ", value: notifyLikes, set: setNotifyLikes },
            { label: "แจ้งเตือนความเห็น 💬", desc: "เมื่อมีคนแสดงความเห็นในวิดีโอของคุณ", value: notifyComments, set: setNotifyComments },
            { label: "แจ้งเตือนผู้ติดตาม 👤", desc: "เมื่อมีคนติดตามคุณ", value: notifyFollows, set: setNotifyFollows },
            { label: "แจ้งเตือนรีโพสต์ 🔄", desc: "เมื่อมีคนรีโพสต์วิดีโอของคุณ", value: notifyReposts, set: setNotifyReposts },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between py-2">
              <div>
                <p className="font-medium text-sm">{item.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{item.desc}</p>
              </div>
              <Switch checked={item.value} onCheckedChange={item.set} />
            </div>
          ))}
        </TabsContent>

        {/* ── ความเป็นส่วนตัว ── */}
        <TabsContent value="privacy" className="p-4 space-y-4">
          <div className="flex items-center justify-between py-2">
            <div>
              <p className="font-medium text-sm">บัญชีส่วนตัว 🔒</p>
              <p className="text-xs text-muted-foreground mt-0.5">เฉพาะผู้ติดตามเท่านั้นที่เห็นวิดีโอ</p>
            </div>
            <Switch checked={privateAccount} onCheckedChange={setPrivateAccount} />
          </div>
          <div className="flex items-center justify-between py-2">
            <div>
              <p className="font-medium text-sm">อนุญาตให้ความเห็น 💬</p>
              <p className="text-xs text-muted-foreground mt-0.5">ให้ผู้อื่นแสดงความเห็นในวิดีโอ</p>
            </div>
            <Switch checked={allowComments} onCheckedChange={setAllowComments} />
          </div>
        </TabsContent>

        {/* ── วิดีโอ ── */}
        <TabsContent value="video" className="p-4 space-y-4">
          <div className="flex items-center justify-between py-2">
            <div>
              <p className="font-medium text-sm">เล่นอัตโนมัติ ▶️</p>
              <p className="text-xs text-muted-foreground mt-0.5">เล่นวิดีโอทันทีเมื่อเลื่อน</p>
            </div>
            <Switch checked={autoPlay} onCheckedChange={setAutoPlay} />
          </div>
          <div className="flex items-center justify-between py-2">
            <div>
              <p className="font-medium text-sm">Wi-Fi เท่านั้น 📶</p>
              <p className="text-xs text-muted-foreground mt-0.5">ดาวน์โหลดวิดีโอเฉพาะบน Wi-Fi</p>
            </div>
            <Switch checked={wifiOnly} onCheckedChange={setWifiOnly} />
          </div>
          <div>
            <Label>คุณภาพวิดีโอ</Label>
            <select value={videoQuality} onChange={(e) => setVideoQuality(e.target.value)} className="w-full mt-2 px-3 py-2 border border-border rounded-xl bg-background text-foreground text-sm">
              <option value="auto">อัตโนมัติ</option>
              <option value="1080p">1080p (HD)</option>
              <option value="720p">720p</option>
              <option value="480p">480p</option>
              <option value="360p">360p (ประหยัดเน็ต)</option>
            </select>
          </div>
        </TabsContent>

        {/* ── ทั่วไป ── */}
        <TabsContent value="general" className="p-4 space-y-4">
          <div className="pt-2 border-t border-border">
            <Button variant="outline" className="w-full rounded-xl" onClick={() => { localStorage.clear(); sessionStorage.clear(); toast.success("ล้างแคชเสร็จสิ้น"); }}>
              ล้างแคช 🗑️
            </Button>
          </div>
          <div className="pt-4">
            <p className="text-xs text-muted-foreground text-center">เวอร์ชัน 1.0.0</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
