import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Search, Home as HomeIcon, Compass, Plus, Bell, User, TrendingUp, Hash } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import VideoFeed from "@/components/VideoFeed";

const TRENDING_HASHTAGS = [
  "ฮาๆ", "เต้น", "ทำอาหาร", "ท่องเที่ยว", "สัตว์น่ารัก",
  "ดนตรี", "กีฬา", "แฟชั่น", "ความรู้", "ตลก"
];

export default function Discover() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [submittedQuery, setSubmittedQuery] = useState("");
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSubmittedQuery(searchQuery.trim());
      setSelectedTag(null);
    }
  };

  const handleTagClick = (tag: string) => {
    setSelectedTag(tag);
    setSearchQuery(tag);
    setSubmittedQuery(tag);
  };

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background border-b border-border px-4 py-3">
        <h1 className="font-bold text-lg mb-3">ค้นพบ</h1>
        <form onSubmit={handleSearch}>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="ค้นหาวิดีโอ, แฮชแท็ก..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 rounded-full"
            />
          </div>
        </form>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {!submittedQuery ? (
          <>
            {/* Trending Hashtags */}
            <div className="px-4 py-4">
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="w-5 h-5 text-accent" />
                <h2 className="font-semibold">กำลังฮิตตอนนี้</h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {TRENDING_HASHTAGS.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => handleTagClick(tag)}
                    className="flex items-center gap-1 px-3 py-2 rounded-full bg-accent/10 text-accent hover:bg-accent/20 transition-colors text-sm font-medium"
                  >
                    <Hash className="w-3 h-3" />
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* All Videos */}
            <div className="px-4 pb-2">
              <h2 className="font-semibold mb-3">วิดีโอทั้งหมด</h2>
            </div>
            <div className="h-[calc(100vh-280px)]">
              <VideoFeed category="explore" />
            </div>
          </>
        ) : (
          <>
            <div className="px-4 py-3 border-b border-border">
              <p className="text-sm text-muted-foreground">
                ผลลัพธ์สำหรับ <span className="font-semibold text-foreground">"{submittedQuery}"</span>
              </p>
              <button
                onClick={() => { setSubmittedQuery(""); setSearchQuery(""); setSelectedTag(null); }}
                className="text-xs text-accent mt-1"
              >
                ล้างการค้นหา
              </button>
            </div>
            <div className="h-[calc(100vh-220px)]">
              <VideoFeed category="explore" />
            </div>
          </>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="sticky bottom-0 z-40 bg-background border-t border-border px-4 py-3 flex items-center justify-around">
        <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="flex flex-col items-center gap-1">
          <HomeIcon className="w-5 h-5" />
          <span className="text-xs">หน้าแรก</span>
        </Button>
        <Button variant="ghost" size="sm" onClick={() => navigate("/discover")} className="flex flex-col items-center gap-1 text-accent">
          <Compass className="w-5 h-5 fill-accent" />
          <span className="text-xs font-semibold">ค้นพบ</span>
        </Button>
        {isAuthenticated ? (
          <>
            <Button variant="ghost" size="sm" onClick={() => navigate("/create")} className="flex flex-col items-center gap-1">
              <Plus className="w-5 h-5" />
              <span className="text-xs">สร้างโพสต์</span>
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/notifications")} className="flex flex-col items-center gap-1">
              <Bell className="w-5 h-5" />
              <span className="text-xs">แจ้งเตือน</span>
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/profile")} className="flex flex-col items-center gap-1">
              <User className="w-5 h-5" />
              <span className="text-xs">โปรไฟล์</span>
            </Button>
          </>
        ) : (
          <>
            <Button variant="ghost" size="sm" onClick={() => window.location.href = getLoginUrl()} className="flex flex-col items-center gap-1">
              <Plus className="w-5 h-5" />
              <span className="text-xs">สร้างโพสต์</span>
            </Button>
            <Button variant="ghost" size="sm" onClick={() => window.location.href = getLoginUrl()} className="flex flex-col items-center gap-1">
              <User className="w-5 h-5" />
              <span className="text-xs">โปรไฟล์</span>
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
