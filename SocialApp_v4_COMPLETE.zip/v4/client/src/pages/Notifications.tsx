import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft, Heart, MessageCircle, UserPlus, RotateCcw, Share2, Home as HomeIcon, Compass, Plus, Bell, User } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";

export default function Notifications() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  // ดึงการแจ้งเตือนจาก API จริง
  const { data: notifications = [], isLoading, refetch } = trpc.notifications.getAll.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const markReadMutation = trpc.notifications.markAllRead.useMutation({
    onSuccess: () => refetch(),
  });

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "like": return <Heart className="w-5 h-5 text-red-500 fill-red-500" />;
      case "comment": return <MessageCircle className="w-5 h-5 text-blue-500" />;
      case "follow": return <UserPlus className="w-5 h-5 text-green-500" />;
      case "repost": return <RotateCcw className="w-5 h-5 text-purple-500" />;
      case "share": return <Share2 className="w-5 h-5 text-orange-500" />;
      default: return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };

  const getNotificationText = (notification: any) => {
    const name = notification.actor?.name || "ผู้ใช้";
    switch (notification.type) {
      case "like": return `${name} ถูกใจวิดีโอของคุณ`;
      case "comment": return `${name} แสดงความเห็นในวิดีโอของคุณ`;
      case "follow": return `${name} ติดตามคุณ`;
      case "repost": return `${name} รีโพสต์วิดีโอของคุณ`;
      case "share": return `${name} แชร์วิดีโอของคุณ`;
      default: return "มีการแจ้งเตือนใหม่";
    }
  };

  const formatTime = (date: Date) => {
    const diffMs = Date.now() - new Date(date).getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffMins < 1) return "เพิ่งเดี๋ยว";
    if (diffMins < 60) return `${diffMins} นาทีที่แล้ว`;
    if (diffHours < 24) return `${diffHours} ชั่วโมงที่แล้ว`;
    if (diffDays < 7) return `${diffDays} วันที่แล้ว`;
    return new Date(date).toLocaleDateString("th-TH");
  };

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center h-screen gap-4">
        <Bell className="w-16 h-16 text-muted-foreground" />
        <p className="text-muted-foreground">กรุณาเข้าสู่ระบบเพื่อดูการแจ้งเตือน</p>
        <Button onClick={() => window.location.href = getLoginUrl()}>เข้าสู่ระบบ</Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="rounded-full">
            <ChevronLeft className="w-5 h-5" />
          </Button>
          <h1 className="font-bold text-lg">แจ้งเตือน</h1>
        </div>
        {notifications.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => markReadMutation.mutate()}
            className="text-xs text-accent"
          >
            อ่านทั้งหมด
          </Button>
        )}
      </div>

      {/* Notifications List */}
      <div className="flex-1 overflow-y-auto pb-20">
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin w-8 h-8 border-2 border-accent border-t-transparent rounded-full" />
          </div>
        ) : notifications.length > 0 ? (
          notifications.map((notification: any) => (
            <div
              key={notification.id}
              className={`px-4 py-3 border-b border-border flex items-start gap-3 cursor-pointer hover:bg-muted/50 transition-colors ${
                !notification.isRead ? "bg-accent/5" : ""
              }`}
            >
              {/* Unread dot */}
              {!notification.isRead && (
                <div className="absolute left-2 w-2 h-2 bg-accent rounded-full mt-4" />
              )}

              {/* Avatar */}
              <div className="flex-shrink-0">
                {notification.actor?.profileImageUrl ? (
                  <img
                    src={notification.actor.profileImageUrl}
                    alt={notification.actor.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center text-accent-foreground font-bold text-sm">
                    {(notification.actor?.name || "?")[0]}
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start gap-2">
                  <div className="flex-1">
                    <p className="text-sm">
                      <span className="font-semibold">{notification.actor?.name}</span>{" "}
                      <span className="text-muted-foreground">{getNotificationText(notification)}</span>
                    </p>
                    {notification.video && (
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-1">
                        {notification.video.title}
                      </p>
                    )}
                  </div>
                  {getNotificationIcon(notification.type)}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {formatTime(notification.createdAt)}
                </p>
              </div>
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center h-64 gap-3">
            <Bell className="w-12 h-12 text-muted-foreground" />
            <p className="text-muted-foreground">ยังไม่มีการแจ้งเตือน</p>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="sticky bottom-0 z-40 bg-background border-t border-border px-4 py-3 flex items-center justify-around">
        <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="flex flex-col items-center gap-1">
          <HomeIcon className="w-5 h-5" />
          <span className="text-xs">หน้าแรก</span>
        </Button>
        <Button variant="ghost" size="sm" onClick={() => navigate("/discover")} className="flex flex-col items-center gap-1">
          <Compass className="w-5 h-5" />
          <span className="text-xs">ค้นพบ</span>
        </Button>
        <Button variant="ghost" size="sm" onClick={() => navigate("/create")} className="flex flex-col items-center gap-1">
          <Plus className="w-5 h-5" />
          <span className="text-xs">สร้างโพสต์</span>
        </Button>
        <Button variant="ghost" size="sm" onClick={() => navigate("/notifications")} className="flex flex-col items-center gap-1 text-accent">
          <Bell className="w-5 h-5 fill-accent" />
          <span className="text-xs font-semibold">แจ้งเตือน</span>
        </Button>
        <Button variant="ghost" size="sm" onClick={() => navigate("/profile")} className="flex flex-col items-center gap-1">
          <User className="w-5 h-5" />
          <span className="text-xs">โปรไฟล์</span>
        </Button>
      </div>
    </div>
  );
}
