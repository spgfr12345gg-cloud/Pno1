import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Heart, Bookmark, Settings, LogOut, Camera, Play } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState, useRef } from "react";
import { toast } from "sonner";

export default function Profile() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("videos");
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);

  const utils = trpc.useUtils();

  // ดึงวิดีโอของตัวเอง
  const { data: userVideos = [] } = trpc.videos.getUserVideos.useQuery(
    { userId: user?.id || 0 },
    { enabled: !!user?.id }
  );

  // ดึงผู้ติดตาม
  const { data: followerCount = 0 } = trpc.follows.getFollowerCount.useQuery(
    { userId: user?.id || 0 },
    { enabled: !!user?.id }
  );

  // ดึงกำลังติดตาม
  const { data: followingCount = 0 } = trpc.follows.getFollowingCount.useQuery(
    { userId: user?.id || 0 },
    { enabled: !!user?.id }
  );

  // ดึงวิดีโอที่บันทึกไว้
  const { data: bookmarkedVideos = [] } = trpc.bookmarks.getAll.useQuery(
    { limit: 20, offset: 0 },
    { enabled: !!user?.id && activeTab === "bookmarks" }
  );

  // ดึงวิดีโอที่กดใจ
  const { data: likedVideos = [] } = trpc.likes.getLikedVideos.useQuery(
    { limit: 20, offset: 0 },
    { enabled: !!user?.id && activeTab === "liked" }
  );

  // mutation อัปเดตรูปโปรไฟล์
  const updateProfileMutation = trpc.users.updateProfile.useMutation({
    onSuccess: () => {
      utils.auth.me.invalidate();
      toast.success("อัปเดตรูปโปรไฟล์แล้ว ✅");
    },
    onError: () => toast.error("เกิดข้อผิดพลาด กรุณาลองใหม่"),
  });

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("กรุณาเลือกไฟล์รูปภาพ");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("รูปภาพต้องไม่เกิน 5MB");
      return;
    }

    setIsUploadingPhoto(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("type", "image");

      const res = await fetch("/api/upload", { method: "POST", body: formData });
      if (!res.ok) throw new Error("Upload failed");
      const { url } = await res.json();

      await updateProfileMutation.mutateAsync({ profileImageUrl: url });
    } catch {
      toast.error("อัปโหลดรูปไม่สำเร็จ");
    } finally {
      setIsUploadingPhoto(false);
      if (photoInputRef.current) photoInputRef.current.value = "";
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p className="text-muted-foreground">กรุณาเข้าสู่ระบบ</p>
      </div>
    );
  }

  const VideoGrid = ({ videos }: { videos: any[] }) => (
    videos.length > 0 ? (
      <div className="grid grid-cols-3 gap-0.5">
        {videos.map((item) => {
          const video = item.video ?? item;
          return (
            <div
              key={video.id}
              className="aspect-[9/16] bg-muted overflow-hidden cursor-pointer relative group"
            >
              {video.thumbnailUrl ? (
                <img src={video.thumbnailUrl} alt={video.title || "วิดีโอ"} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-accent/30 to-accent/10 flex items-center justify-center">
                  <Play className="w-8 h-8 text-accent/60" />
                </div>
              )}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
            </div>
          );
        })}
      </div>
    ) : (
      <div className="text-center py-16">
        <p className="text-muted-foreground text-sm">ยังไม่มีวิดีโอ</p>
      </div>
    )
  );

  return (
    <div className="min-h-screen bg-background text-foreground pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background border-b border-border px-4 py-3 flex items-center justify-between">
        <h1 className="font-bold text-lg">โปรไฟล์</h1>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" onClick={() => navigate("/settings")} className="rounded-full">
            <Settings className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="sm" onClick={handleLogout} className="rounded-full">
            <LogOut className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Profile Header */}
      <div className="px-4 py-6 border-b border-border">
        <div className="flex items-start gap-4">
          {/* Avatar + เปลี่ยนรูป */}
          <div className="flex-shrink-0 relative">
            {user.profileImageUrl ? (
              <img src={user.profileImageUrl} alt={user.name || "ผู้ใช้"} className="w-20 h-20 rounded-full object-cover border-2 border-accent/30" />
            ) : (
              <div className="w-20 h-20 rounded-full bg-accent flex items-center justify-center text-accent-foreground font-bold text-2xl border-2 border-accent/30">
                {(user.name || "ผ")[0]}
              </div>
            )}
            {/* ปุ่มเปลี่ยนรูป */}
            <button
              onClick={() => photoInputRef.current?.click()}
              disabled={isUploadingPhoto}
              className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-accent flex items-center justify-center shadow-md hover:opacity-90 transition-opacity"
            >
              {isUploadingPhoto
                ? <div className="w-3 h-3 border border-white border-t-transparent rounded-full animate-spin" />
                : <Camera className="w-3.5 h-3.5 text-accent-foreground" />
              }
            </button>
            <input ref={photoInputRef} type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" />
          </div>

          {/* ข้อมูลผู้ใช้ */}
          <div className="flex-1">
            <h2 className="font-bold text-xl">{user.name || "ผู้ใช้"}</h2>
            {user.bio && <p className="text-sm text-muted-foreground mt-1">{user.bio}</p>}

            {/* Stats */}
            <div className="flex gap-5 mt-4">
              <div className="text-center">
                <p className="font-bold text-lg">{userVideos.length}</p>
                <p className="text-xs text-muted-foreground">วิดีโอ</p>
              </div>
              <button className="text-center" onClick={() => navigate(`/followers/${user.id}`)}>
                <p className="font-bold text-lg">{followerCount.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">ผู้ติดตาม</p>
              </button>
              <button className="text-center" onClick={() => navigate(`/following/${user.id}`)}>
                <p className="font-bold text-lg">{followingCount.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">กำลังติดตาม</p>
              </button>
            </div>
          </div>
        </div>

        {/* ปุ่มแก้ไขโปรไฟล์ */}
        <Button variant="outline" className="w-full mt-4 rounded-xl" onClick={() => navigate("/settings")}>
          แก้ไขโปรไฟล์
        </Button>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-3 rounded-none border-b border-border bg-background h-11">
          <TabsTrigger value="videos" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-accent data-[state=active]:text-accent">
            วิดีโอ
          </TabsTrigger>
          <TabsTrigger value="liked" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-accent data-[state=active]:text-accent flex items-center gap-1">
            <Heart className="w-4 h-4" /> ถูกใจ
          </TabsTrigger>
          <TabsTrigger value="bookmarks" className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-accent data-[state=active]:text-accent flex items-center gap-1">
            <Bookmark className="w-4 h-4" /> บันทึก
          </TabsTrigger>
        </TabsList>

        <TabsContent value="videos" className="mt-0">
          <VideoGrid videos={userVideos} />
        </TabsContent>

        <TabsContent value="liked" className="mt-0">
          <VideoGrid videos={likedVideos} />
        </TabsContent>

        <TabsContent value="bookmarks" className="mt-0">
          <VideoGrid videos={bookmarkedVideos} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
