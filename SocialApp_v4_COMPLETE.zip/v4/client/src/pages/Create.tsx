import { useState, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  ChevronLeft, Video, ImageIcon, X, Plus,
  Home as HomeIcon, Compass, Bell, User, Loader2
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";

type MediaType = "video" | "image" | null;

export default function Create() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  // ฟิลด์ข้อมูล
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [hashtags, setHashtags] = useState("");
  const [category, setCategory] = useState<"explore" | "recommended">("explore");

  // ไฟล์มีเดีย
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string>("");
  const [mediaType, setMediaType] = useState<MediaType>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const videoInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const createVideoMutation = trpc.videos.create.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center h-screen gap-4">
        <Video className="w-16 h-16 text-muted-foreground" />
        <p className="text-muted-foreground">กรุณาเข้าสู่ระบบก่อน</p>
        <Button onClick={() => window.location.href = getLoginUrl()}>เข้าสู่ระบบ</Button>
      </div>
    );
  }

  // เลือกไฟล์วิดีโอ
  const handleVideoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("video/")) {
      toast.error("กรุณาเลือกไฟล์วิดีโอ (.mp4, .mov, .avi)");
      return;
    }

    // เช็คขนาดไฟล์ไม่เกิน 500MB
    if (file.size > 500 * 1024 * 1024) {
      toast.error("ไฟล์วิดีโอต้องมีขนาดไม่เกิน 500MB");
      return;
    }

    clearMedia();
    setMediaFile(file);
    setMediaType("video");
    const preview = URL.createObjectURL(file);
    setMediaPreview(preview);
  };

  // เลือกไฟล์รูปภาพ
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("กรุณาเลือกไฟล์รูปภาพ (.jpg, .png, .gif, .webp)");
      return;
    }

    if (file.size > 20 * 1024 * 1024) {
      toast.error("รูปภาพต้องมีขนาดไม่เกิน 20MB");
      return;
    }

    clearMedia();
    setMediaFile(file);
    setMediaType("image");
    const preview = URL.createObjectURL(file);
    setMediaPreview(preview);
  };

  const clearMedia = () => {
    if (mediaPreview) URL.revokeObjectURL(mediaPreview);
    setMediaFile(null);
    setMediaPreview("");
    setMediaType(null);
    setUploadProgress(0);
    if (videoInputRef.current) videoInputRef.current.value = "";
    if (imageInputRef.current) imageInputRef.current.value = "";
  };

  // จำลอง progress bar ขณะอัปโหลด
  const simulateProgress = () => {
    setUploadProgress(0);
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) { clearInterval(interval); return 90; }
        return prev + Math.random() * 15;
      });
    }, 300);
    return interval;
  };

  const handlePost = async () => {
    if (!mediaFile) {
      toast.error("กรุณาเลือกวิดีโอหรือรูปภาพก่อน");
      return;
    }
    if (!title.trim()) {
      toast.error("กรุณาใส่ชื่อโพสต์");
      return;
    }

    setIsUploading(true);
    const progressInterval = simulateProgress();

    try {
      // อัปโหลดไฟล์ผ่าน FormData ไปยัง /api/upload
      const formData = new FormData();
      formData.append("file", mediaFile);
      formData.append("type", mediaType || "video");

      const uploadRes = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!uploadRes.ok) {
        throw new Error("อัปโหลดล้มเหลว");
      }

      const { url } = await uploadRes.json();
      setUploadProgress(95);

      // บันทึก video/post ลง database
      await createVideoMutation.mutateAsync({
        title: title.trim(),
        description: description.trim(),
        videoUrl: url,
        category,
        hashtags: hashtags
          .split(/[,\s#]+/)
          .filter(t => t.trim())
          .map(t => t.replace(/^#/, ""))
          .join(","),
      });

      clearInterval(progressInterval);
      setUploadProgress(100);

      toast.success("🎉 โพสต์สำเร็จแล้ว!");
      setTimeout(() => navigate("/"), 800);
    } catch (error: any) {
      clearInterval(progressInterval);
      setUploadProgress(0);
      toast.error(error?.message || "เกิดข้อผิดพลาด กรุณาลองใหม่");
    } finally {
      setIsUploading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background border-b border-border px-4 py-3 flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={() => navigate("/")} className="rounded-full">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h1 className="font-bold text-lg">สร้างโพสต์ใหม่</h1>
      </div>

      {/* Scrollable Form */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-2xl mx-auto px-4 py-6 space-y-6 pb-32">

          {/* ── Zone เลือกไฟล์ ── */}
          {!mediaFile ? (
            <div className="space-y-3">
              <p className="text-sm font-medium text-muted-foreground">เลือกประเภทสื่อ</p>

              {/* ปุ่มเลือกวิดีโอ */}
              <button
                onClick={() => videoInputRef.current?.click()}
                className="w-full flex items-center gap-4 p-5 border-2 border-dashed border-border rounded-2xl hover:border-accent hover:bg-accent/5 transition-all group"
              >
                <div className="w-14 h-14 rounded-2xl bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors flex-shrink-0">
                  <Video className="w-7 h-7 text-accent" />
                </div>
                <div className="text-left">
                  <p className="font-semibold">อัปโหลดวิดีโอ</p>
                  <p className="text-xs text-muted-foreground mt-0.5">MP4, MOV, AVI — ไม่เกิน 500MB</p>
                </div>
                <Plus className="w-5 h-5 text-muted-foreground ml-auto" />
              </button>

              {/* ปุ่มเลือกรูปภาพ */}
              <button
                onClick={() => imageInputRef.current?.click()}
                className="w-full flex items-center gap-4 p-5 border-2 border-dashed border-border rounded-2xl hover:border-accent hover:bg-accent/5 transition-all group"
              >
                <div className="w-14 h-14 rounded-2xl bg-purple-100 dark:bg-purple-900/20 flex items-center justify-center group-hover:bg-purple-200 transition-colors flex-shrink-0">
                  <ImageIcon className="w-7 h-7 text-purple-500" />
                </div>
                <div className="text-left">
                  <p className="font-semibold">อัปโหลดรูปภาพ</p>
                  <p className="text-xs text-muted-foreground mt-0.5">JPG, PNG, GIF, WEBP — ไม่เกิน 20MB</p>
                </div>
                <Plus className="w-5 h-5 text-muted-foreground ml-auto" />
              </button>

              {/* Hidden inputs */}
              <input ref={videoInputRef} type="file" accept="video/*" onChange={handleVideoSelect} className="hidden" />
              <input ref={imageInputRef} type="file" accept="image/*" onChange={handleImageSelect} className="hidden" />
            </div>
          ) : (
            /* ── Preview ไฟล์ที่เลือก ── */
            <div className="relative rounded-2xl overflow-hidden bg-black">
              {mediaType === "video" ? (
                <video
                  src={mediaPreview}
                  className="w-full aspect-[9/16] max-h-72 object-contain bg-black"
                  controls
                  playsInline
                />
              ) : (
                <img
                  src={mediaPreview}
                  alt="preview"
                  className="w-full aspect-square object-cover"
                />
              )}

              {/* ข้อมูลไฟล์ */}
              <div className="absolute bottom-0 left-0 right-0 bg-black/60 px-3 py-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {mediaType === "video"
                    ? <Video className="w-4 h-4 text-white" />
                    : <ImageIcon className="w-4 h-4 text-white" />
                  }
                  <span className="text-white text-xs truncate max-w-[180px]">{mediaFile.name}</span>
                  <span className="text-white/60 text-xs">{formatFileSize(mediaFile.size)}</span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearMedia}
                  className="rounded-full h-7 w-7 p-0 bg-white/20 hover:bg-white/40 text-white"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}

          {/* ── ชื่อโพสต์ ── */}
          <div>
            <label className="block text-sm font-medium mb-2">
              ชื่อโพสต์ <span className="text-red-500">*</span>
            </label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="ใส่ชื่อโพสต์ของคุณ..."
              maxLength={100}
              className="rounded-xl"
            />
            <p className="text-xs text-muted-foreground mt-1 text-right">{title.length}/100</p>
          </div>

          {/* ── คำอธิบาย ── */}
          <div>
            <label className="block text-sm font-medium mb-2">คำอธิบาย</label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="บอกเล่าเรื่องราวของโพสต์นี้..."
              maxLength={500}
              rows={3}
              className="rounded-xl resize-none"
            />
            <p className="text-xs text-muted-foreground mt-1 text-right">{description.length}/500</p>
          </div>

          {/* ── แฮชแท็ก ── */}
          <div>
            <label className="block text-sm font-medium mb-2">แฮชแท็ก</label>
            <Input
              value={hashtags}
              onChange={(e) => setHashtags(e.target.value)}
              placeholder="#ฮา #เต้น #ท่องเที่ยว"
              className="rounded-xl"
            />
            <p className="text-xs text-muted-foreground mt-1">
              คั่นด้วยเว้นวรรคหรือ # เช่น #สนุก #ตลก
            </p>
          </div>

          {/* ── หมวดหมู่ ── */}
          <div>
            <label className="block text-sm font-medium mb-2">หมวดหมู่</label>
            <div className="flex gap-2">
              {(["explore", "recommended"] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`flex-1 py-2 rounded-xl text-sm font-medium border transition-all ${
                    category === cat
                      ? "bg-accent text-accent-foreground border-accent"
                      : "border-border text-muted-foreground hover:border-accent/50"
                  }`}
                >
                  {cat === "explore" ? "🔍 สำรวจ" : "⭐ แนะนำ"}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ── ปุ่มโพสต์ ติดด้านล่าง ── */}
      <div className="sticky bottom-0 z-40 bg-background border-t border-border px-4 py-4 space-y-2">
        {/* Progress bar */}
        {isUploading && (
          <div className="w-full bg-muted rounded-full h-1.5 mb-2">
            <div
              className="bg-accent h-1.5 rounded-full transition-all duration-300"
              style={{ width: `${uploadProgress}%` }}
            />
          </div>
        )}

        <div className="flex gap-3">
          <Button
            variant="outline"
            className="flex-1 rounded-xl h-12"
            onClick={() => navigate("/")}
            disabled={isUploading}
          >
            ยกเลิก
          </Button>

          <Button
            className="flex-1 rounded-xl h-12 text-base font-semibold"
            onClick={handlePost}
            disabled={isUploading || !mediaFile || !title.trim()}
          >
            {isUploading ? (
              <span className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                กำลังโพสต์... {Math.round(uploadProgress)}%
              </span>
            ) : (
              "📤 โพสต์เลย"
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
