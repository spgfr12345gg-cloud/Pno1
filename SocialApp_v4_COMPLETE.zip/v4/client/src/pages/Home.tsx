import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Search, Home as HomeIcon, Compass, Users, Plus, Bell, User } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import VideoFeed from "@/components/VideoFeed";
import { useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState("explore");
  const [searchQuery, setSearchQuery] = useState("");
  const [, navigate] = useLocation();

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Top Navigation Bar */}
      <div className="sticky top-0 z-40 bg-background border-b border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center text-accent-foreground font-bold text-lg">
            S
          </div>
          <span className="font-bold text-lg">ShortVideo</span>
        </div>

        {/* Search Bar */}
        <div className="flex-1 max-w-md mx-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="ค้นหา..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 rounded-full"
            />
          </div>
        </div>

        {/* Auth Button */}
        <div>
          {isAuthenticated ? (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/profile")}
              className="rounded-full"
            >
              <User className="w-5 h-5" />
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={() => (window.location.href = getLoginUrl())}
              className="rounded-full"
            >
              เข้าสู่ระบบ
            </Button>
          )}
        </div>
      </div>

      {/* Main Content - Video Feed */}
      <div className="flex-1 overflow-hidden">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
          <TabsList className="w-full justify-start rounded-none border-b border-border px-4 py-2 bg-background">
            <TabsTrigger value="explore" className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent">
              <Compass className="w-4 h-4 mr-2" />
              สำรวจ
            </TabsTrigger>
            {isAuthenticated && (
              <TabsTrigger value="following" className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent">
                <Users className="w-4 h-4 mr-2" />
                กำลังติดตาม
              </TabsTrigger>
            )}
            <TabsTrigger value="recommended" className="rounded-none border-b-2 border-transparent data-[state=active]:border-accent">
              <HomeIcon className="w-4 h-4 mr-2" />
              แนะนำคลิป
            </TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-hidden">
            <TabsContent value="explore" className="h-full m-0">
              <VideoFeed category="explore" />
            </TabsContent>

            {isAuthenticated && (
              <TabsContent value="following" className="h-full m-0">
                <VideoFeed category="following" />
              </TabsContent>
            )}

            <TabsContent value="recommended" className="h-full m-0">
              <VideoFeed category="recommended" />
            </TabsContent>
          </div>
        </Tabs>
      </div>

      {/* Bottom Navigation Bar */}
      <div className="sticky bottom-0 z-40 bg-background border-t border-border px-4 py-3 flex items-center justify-around">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate("/")}
          className="flex flex-col items-center gap-1"
        >
          <HomeIcon className="w-5 h-5" />
          <span className="text-xs">หน้าแรก</span>
        </Button>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate("/discover")}
          className="flex flex-col items-center gap-1"
        >
          <Compass className="w-5 h-5" />
          <span className="text-xs">ค้นพบ</span>
        </Button>

        {isAuthenticated ? (
          <>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/create")}
              className="flex flex-col items-center gap-1"
            >
              <Plus className="w-5 h-5" />
              <span className="text-xs">สร้างโพสต์</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/notifications")}
              className="flex flex-col items-center gap-1"
            >
              <Bell className="w-5 h-5" />
              <span className="text-xs">แจ้งเตือน</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/profile")}
              className="flex flex-col items-center gap-1"
            >
              <User className="w-5 h-5" />
              <span className="text-xs">โปรไฟล์</span>
            </Button>
          </>
        ) : (
          <>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => (window.location.href = getLoginUrl())}
              className="flex flex-col items-center gap-1"
            >
              <Plus className="w-5 h-5" />
              <span className="text-xs">สร้างโพสต์</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => (window.location.href = getLoginUrl())}
              className="flex flex-col items-center gap-1"
            >
              <User className="w-5 h-5" />
              <span className="text-xs">โปรไฟล์</span>
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
