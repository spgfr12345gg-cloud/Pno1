import { describe, it, expect, beforeEach, vi } from "vitest";
import * as db from "./db";
import { appRouter } from "./routers";

// Mock database functions
vi.mock("./db", () => ({
  getDb: vi.fn(),
  getVideosByCategory: vi.fn(),
  getFollowingVideos: vi.fn(),
  getVideoById: vi.fn(),
  getUserVideos: vi.fn(),
  getLikeCount: vi.fn(),
  isVideoLikedByUser: vi.fn(),
  addLike: vi.fn(),
  removeLike: vi.fn(),
  getCommentCount: vi.fn(),
  getCommentsByVideo: vi.fn(),
  createComment: vi.fn(),
  isVideoBookmarkedByUser: vi.fn(),
  addBookmark: vi.fn(),
  removeBookmark: vi.fn(),
  getRepostCount: vi.fn(),
  createRepost: vi.fn(),
  getFollowerCount: vi.fn(),
  getFollowingCount: vi.fn(),
  isUserFollowing: vi.fn(),
  addFollow: vi.fn(),
  removeFollow: vi.fn(),
  createVideo: vi.fn(),
  getUserById: vi.fn(),
}));

describe("Videos Router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("getByCategory", () => {
    it("should return videos for a given category", async () => {
      const mockVideos = [
        {
          id: 1,
          userId: 1,
          title: "Test Video",
          description: "Test Description",
          videoUrl: "https://example.com/video.mp4",
          category: "explore",
          hashtags: "[]",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      vi.mocked(db.getVideosByCategory).mockResolvedValue(mockVideos);

      const caller = appRouter.createCaller({ user: null, req: {}, res: {} } as any);
      const result = await caller.videos.getByCategory({
        category: "explore",
        limit: 20,
        offset: 0,
      });

      expect(result).toEqual(mockVideos);
      expect(db.getVideosByCategory).toHaveBeenCalledWith("explore", 20, 0);
    });
  });

  describe("likes", () => {
    it("should toggle like status", async () => {
      vi.mocked(db.isVideoLikedByUser).mockResolvedValue(false);
      vi.mocked(db.addLike).mockResolvedValue(undefined);

      const caller = appRouter.createCaller({
        user: { id: 1 },
        req: {},
        res: {},
      } as any);

      const result = await caller.likes.toggle({ videoId: 1 });

      expect(result.success).toBe(true);
      expect(result.isLiked).toBe(true);
      expect(db.addLike).toHaveBeenCalledWith(1, 1);
    });

    it("should remove like if already liked", async () => {
      vi.mocked(db.isVideoLikedByUser).mockResolvedValue(true);
      vi.mocked(db.removeLike).mockResolvedValue(undefined);

      const caller = appRouter.createCaller({
        user: { id: 1 },
        req: {},
        res: {},
      } as any);

      const result = await caller.likes.toggle({ videoId: 1 });

      expect(result.success).toBe(true);
      expect(result.isLiked).toBe(false);
      expect(db.removeLike).toHaveBeenCalledWith(1, 1);
    });
  });

  describe("bookmarks", () => {
    it("should toggle bookmark status", async () => {
      vi.mocked(db.isVideoBookmarkedByUser).mockResolvedValue(false);
      vi.mocked(db.addBookmark).mockResolvedValue(undefined);

      const caller = appRouter.createCaller({
        user: { id: 1 },
        req: {},
        res: {},
      } as any);

      const result = await caller.bookmarks.toggle({ videoId: 1 });

      expect(result.success).toBe(true);
      expect(result.isBookmarked).toBe(true);
      expect(db.addBookmark).toHaveBeenCalledWith(1, 1);
    });
  });

  describe("comments", () => {
    it("should create a comment", async () => {
      vi.mocked(db.createComment).mockResolvedValue(undefined);

      const caller = appRouter.createCaller({
        user: { id: 1 },
        req: {},
        res: {},
      } as any);

      const result = await caller.comments.create({
        videoId: 1,
        content: "Great video!",
      });

      expect(result.success).toBe(true);
      expect(db.createComment).toHaveBeenCalledWith(1, 1, "Great video!", undefined);
    });
  });

  describe("follows", () => {
    it("should toggle follow status", async () => {
      vi.mocked(db.isUserFollowing).mockResolvedValue(false);
      vi.mocked(db.addFollow).mockResolvedValue(undefined);

      const caller = appRouter.createCaller({
        user: { id: 1 },
        req: {},
        res: {},
      } as any);

      const result = await caller.follows.toggle({ userId: 2 });

      expect(result.success).toBe(true);
      expect(result.isFollowing).toBe(true);
      expect(db.addFollow).toHaveBeenCalledWith(1, 2);
    });

    it("should prevent self-following", async () => {
      const caller = appRouter.createCaller({
        user: { id: 1 },
        req: {},
        res: {},
      } as any);

      await expect(caller.follows.toggle({ userId: 1 })).rejects.toThrow();
    });
  });
});
