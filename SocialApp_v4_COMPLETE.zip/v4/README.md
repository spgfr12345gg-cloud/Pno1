# 📱 Social App v4 — ไฟล์ครบทุกอย่าง

## วางไฟล์ตามโครงสร้างนี้

```
client/src/
├── App.tsx                  ← แทนที่ของเดิม
├── index.css
├── pages/
│   ├── Home.tsx
│   ├── Discover.tsx
│   ├── Create.tsx
│   ├── Profile.tsx
│   ├── Settings.tsx
│   ├── Notifications.tsx
│   └── AdminPanel.tsx       ← หลังบ้าน
├── components/
│   ├── VideoFeed.tsx
│   └── ShareModal.tsx

server/
├── routers.ts
├── db.ts
└── routes/upload.ts

drizzle/
├── schema.ts
└── migrations/
```

## ติดตั้ง
npm install multer @types/multer uuid @types/uuid

## เพิ่มใน server/index.ts
import { uploadHandler } from "./routes/upload";
app.use("/uploads", express.static("public/uploads"));
app.post("/api/upload", ...uploadHandler);

## รัน migration (schema เปลี่ยน)
npx drizzle-kit push

## เข้า Admin Panel
/admin — ต้องเป็น role=admin เท่านั้น
