import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, bigint } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

// ── USERS ──────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  bio: text("bio"),
  profileImageUrl: text("profileImageUrl"),

  // ── ฟีเจอร์ใหม่ ──
  isVerified: boolean("isVerified").default(false).notNull(),   // ✅ เครื่องหมายถูกสีฟ้า
  isBanned: boolean("isBanned").default(false).notNull(),       // บัญชีถูกแบน
  isFake: boolean("isFake").default(false).notNull(),           // บัญชีปลอม (สร้างโดย admin)
  followerCount: int("followerCount").default(0).notNull(),     // cache จำนวนผู้ติดตาม
  followingCount: int("followingCount").default(0).notNull(),   // cache จำนวนกำลังติดตาม

  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ── VIDEOS ─────────────────────────────────────────────
export const videos = mysqlTable("videos", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: text("title"),
  description: text("description"),
  videoUrl: text("videoUrl").notNull(),
  thumbnailUrl: text("thumbnailUrl"),
  hashtags: text("hashtags"),
  category: varchar("category", { length: 50 }).default("explore"),

  // ── จำนวนจริง (อัปเดตทุกครั้งที่มี action) ──
  viewCount: bigint("viewCount", { mode: "number" }).default(0).notNull(),
  likeCount: int("likeCount").default(0).notNull(),
  commentCount: int("commentCount").default(0).notNull(),
  bookmarkCount: int("bookmarkCount").default(0).notNull(),
  repostCount: int("repostCount").default(0).notNull(),
  shareCount: int("shareCount").default(0).notNull(),

  isDeleted: boolean("isDeleted").default(false).notNull(),     // ลบโดย admin

  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Video = typeof videos.$inferSelect;
export type InsertVideo = typeof videos.$inferInsert;

// ── LIKES ──────────────────────────────────────────────
export const likes = mysqlTable("likes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  videoId: int("videoId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Like = typeof likes.$inferSelect;

// ── COMMENTS ───────────────────────────────────────────
export const comments = mysqlTable("comments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  videoId: int("videoId").notNull(),
  parentCommentId: int("parentCommentId"),
  content: text("content").notNull(),
  isDeleted: boolean("isDeleted").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Comment = typeof comments.$inferSelect;

// ── BOOKMARKS ──────────────────────────────────────────
export const bookmarks = mysqlTable("bookmarks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  videoId: int("videoId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Bookmark = typeof bookmarks.$inferSelect;

// ── REPOSTS ────────────────────────────────────────────
export const reposts = mysqlTable("reposts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  videoId: int("videoId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Repost = typeof reposts.$inferSelect;

// ── FOLLOWS ────────────────────────────────────────────
export const follows = mysqlTable("follows", {
  id: int("id").autoincrement().primaryKey(),
  followerId: int("followerId").notNull(),
  followingId: int("followingId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Follow = typeof follows.$inferSelect;

// ── NOTIFICATIONS ──────────────────────────────────────
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  actorId: int("actorId").notNull(),
  type: mysqlEnum("type", ["like", "comment", "follow", "repost", "share", "milestone"]).notNull(),
  videoId: int("videoId"),
  commentId: int("commentId"),
  message: text("message"),   // ข้อความ custom เช่น "มีผู้ติดตาม 200 คนแล้ว!"
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Notification = typeof notifications.$inferSelect;

// ── SHARES ─────────────────────────────────────────────
export const shares = mysqlTable("shares", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  videoId: int("videoId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
export type Share = typeof shares.$inferSelect;

// ── RELATIONS ──────────────────────────────────────────
export const usersRelations = relations(users, ({ many }) => ({
  videos: many(videos),
  likes: many(likes),
  comments: many(comments),
  bookmarks: many(bookmarks),
  reposts: many(reposts),
  followers: many(follows, { relationName: "followers" }),
  following: many(follows, { relationName: "following" }),
  notifications: many(notifications),
}));

export const videosRelations = relations(videos, ({ one, many }) => ({
  user: one(users, { fields: [videos.userId], references: [users.id] }),
  likes: many(likes),
  comments: many(comments),
  bookmarks: many(bookmarks),
  reposts: many(reposts),
  notifications: many(notifications),
}));

export const likesRelations = relations(likes, ({ one }) => ({
  user: one(users, { fields: [likes.userId], references: [users.id] }),
  video: one(videos, { fields: [likes.videoId], references: [videos.id] }),
}));

export const commentsRelations = relations(comments, ({ one, many }) => ({
  user: one(users, { fields: [comments.userId], references: [users.id] }),
  video: one(videos, { fields: [comments.videoId], references: [videos.id] }),
  replies: many(comments, { relationName: "replies" }),
  parentComment: one(comments, { fields: [comments.parentCommentId], references: [comments.id], relationName: "replies" }),
}));

export const bookmarksRelations = relations(bookmarks, ({ one }) => ({
  user: one(users, { fields: [bookmarks.userId], references: [users.id] }),
  video: one(videos, { fields: [bookmarks.videoId], references: [videos.id] }),
}));

export const repostsRelations = relations(reposts, ({ one }) => ({
  user: one(users, { fields: [reposts.userId], references: [users.id] }),
  video: one(videos, { fields: [reposts.videoId], references: [videos.id] }),
}));

export const followsRelations = relations(follows, ({ one }) => ({
  follower: one(users, { fields: [follows.followerId], references: [users.id], relationName: "followers" }),
  following: one(users, { fields: [follows.followingId], references: [users.id], relationName: "following" }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, { fields: [notifications.userId], references: [users.id] }),
  actor: one(users, { fields: [notifications.actorId], references: [users.id] }),
  video: one(videos, { fields: [notifications.videoId], references: [videos.id] }),
}));
