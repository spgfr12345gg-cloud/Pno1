import { Request, Response } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";

// โฟลเดอร์เก็บไฟล์อัปโหลด
const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");

// สร้างโฟลเดอร์ถ้ายังไม่มี
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

// กำหนด multer storage
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOAD_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const uniqueName = `${uuidv4()}${ext}`;
    cb(null, uniqueName);
  },
});

// filter ชนิดไฟล์ที่อนุญาต
const fileFilter = (_req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  const allowedTypes = [
    "video/mp4", "video/quicktime", "video/x-msvideo", "video/webm",
    "image/jpeg", "image/png", "image/gif", "image/webp"
  ];
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error("ประเภทไฟล์ไม่รองรับ กรุณาใช้ไฟล์วิดีโอหรือรูปภาพ"));
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 500 * 1024 * 1024, // 500MB
  },
});

// Handler สำหรับ POST /api/upload
export const uploadHandler = [
  upload.single("file"),
  (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "ไม่พบไฟล์ที่อัปโหลด" });
      }

      // URL สำหรับเข้าถึงไฟล์
      const fileUrl = `/uploads/${req.file.filename}`;

      return res.json({
        url: fileUrl,
        filename: req.file.filename,
        originalName: req.file.originalname,
        size: req.file.size,
        type: req.file.mimetype,
      });
    } catch (error: any) {
      console.error("[Upload] Error:", error);
      return res.status(500).json({ error: error.message || "อัปโหลดล้มเหลว" });
    }
  },
];
