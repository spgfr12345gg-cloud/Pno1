import { eq, desc, and, isNull, sql, like, or, ne } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, videos, likes, comments, bookmarks, reposts, follows, notifications, shares } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); }
    catch (e) { console.warn("[DB] connect failed:", e); _db = null; }
  }
  return _db;
}

// ══════════════════════════════════════════
// USER
// ══════════════════════════════════════════
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("openId required");
  const db = await getDb(); if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  (["name", "email", "loginMethod"] as const).forEach((f) => {
    if (user[f] === undefined) return;
    values[f] = user[f] ?? null;
    updateSet[f] = user[f] ?? null;
  });
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (!Object.keys(updateSet).length) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb(); if (!db) return undefined;
  const r = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return r[0];
}

export async function getUserById(id: number) {
  const db = await getDb(); if (!db) return undefined;
  const r = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return r[0];
}

export async function updateUser(id: number, data: { name?: string; bio?: string; profileImageUrl?: string }) {
  const db = await getDb(); if (!db) return;
  const set: Record<string, unknown> = { updatedAt: new Date() };
  if (data.name !== undefined) set.name = data.name;
  if (data.bio !== undefined) set.bio = data.bio;
  if (data.profileImageUrl !== undefined) set.profileImageUrl = data.profileImageUrl;
  await db.update(users).set(set).where(eq(users.id, id));
}

// ค้นหาผู้ใช้
export async function searchUsers(query: string, limit = 20) {
  const db = await getDb(); if (!db) return [];
  return await db.select().from(users)
    .where(and(
      or(like(users.name, `%${query}%`), like(users.email, `%${query}%`)),
      eq(users.isBanned, false)
    ))
    .limit(limit);
}

// ══════════════════════════════════════════
// ADMIN — จัดการผู้ใช้
// ══════════════════════════════════════════
export async function getAllUsers(limit = 50, offset = 0) {
  const db = await getDb(); if (!db) return [];
  return await db.select().from(users).orderBy(desc(users.createdAt)).limit(limit).offset(offset);
}

export async function setUserVerified(userId: number, isVerified: boolean) {
  const db = await getDb(); if (!db) return;
  await db.update(users).set({ isVerified, updatedAt: new Date() }).where(eq(users.id, userId));
}

export async function setUserBanned(userId: number, isBanned: boolean) {
  const db = await getDb(); if (!db) return;
  await db.update(users).set({ isBanned, updatedAt: new Date() }).where(eq(users.id, userId));
}

export async function deleteUser(userId: number) {
  const db = await getDb(); if (!db) return;
  await db.delete(users).where(eq(users.id, userId));
}

// สร้างบัญชีปลอม (เฉพาะ admin)
export async function createFakeUser(data: { name: string; bio?: string; profileImageUrl?: string }) {
  const db = await getDb(); if (!db) return;
  const fakeOpenId = `fake_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  await db.insert(users).values({
    openId: fakeOpenId,
    name: data.name,
    bio: data.bio || "",
    profileImageUrl: data.profileImageUrl || null,
    isFake: true,
    loginMethod: "fake",
    lastSignedIn: new Date(),
  });
  const r = await db.select().from(users).where(eq(users.openId, fakeOpenId)).limit(1);
  return r[0];
}

// เพิ่มผู้ติดตาม batch (admin ให้บัญชีปลอมติดตามช่อง)
export async function adminAddFakeFollowers(targetUserId: number, count: number) {
  const db = await getDb(); if (!db) return 0;
  // ดึง fake accounts ที่ยังไม่ได้ติดตาม
  const fakeUsers = await db.select().from(users)
    .where(and(eq(users.isFake, true), ne(users.id, targetUserId)))
    .limit(count);

  let added = 0;
  for (const fu of fakeUsers) {
    const exists = await db.select().from(follows)
      .where(and(eq(follows.followerId, fu.id), eq(follows.followingId, targetUserId)))
      .limit(1);
    if (!exists.length) {
      await db.insert(follows).values({ followerId: fu.id, followingId: targetUserId, createdAt: new Date() });
      added++;
    }
  }
  // อัปเดต followerCount
  const cnt = await getFollowerCount(targetUserId);
  await db.update(users).set({ followerCount: cnt }).where(eq(users.id, targetUserId));

  // แจ้งเตือน milestone 200+
  if (cnt >= 200) {
    await db.insert(notifications).values({
      userId: targetUserId,
      actorId: targetUserId,
      type: "milestone",
      message: `🎉 ยินดีด้วย! คุณมีผู้ติดตามครบ ${cnt.toLocaleString()} คนแล้ว!`,
      isRead: false,
      createdAt: new Date(),
    });
  }
  return added;
}

// ══════════════════════════════════════════
// VIDEO
// ══════════════════════════════════════════
export async function getVideosByCategory(category: string, limit = 20, offset = 0) {
  const db = await getDb(); if (!db) return [];
  return await db.select().from(videos)
    .where(and(eq(videos.category, category), eq(videos.isDeleted, false)))
    .orderBy(desc(videos.createdAt)).limit(limit).offset(offset);
}

export async function getFollowingVideos(userId: number, limit = 20, offset = 0) {
  const db = await getDb(); if (!db) return [];
  return await db.select().from(videos)
    .where(and(
      sql`${videos.userId} IN (SELECT followingId FROM follows WHERE followerId = ${userId})`,
      eq(videos.isDeleted, false)
    ))
    .orderBy(desc(videos.createdAt)).limit(limit).offset(offset);
}

export async function getVideoById(id: number) {
  const db = await getDb(); if (!db) return undefined;
  const r = await db.select().from(videos).where(and(eq(videos.id, id), eq(videos.isDeleted, false))).limit(1);
  return r[0];
}

export async function getUserVideos(userId: number, limit = 20, offset = 0) {
  const db = await getDb(); if (!db) return [];
  return await db.select().from(videos)
    .where(and(eq(videos.userId, userId), eq(videos.isDeleted, false)))
    .orderBy(desc(videos.createdAt)).limit(limit).offset(offset);
}

export async function createVideo(userId: number, title: string, description: string, videoUrl: string, category: string, hashtags: string) {
  const db = await getDb(); if (!db) return;
  await db.insert(videos).values({ userId, title, description, videoUrl, category, hashtags, createdAt: new Date(), updatedAt: new Date() });
}

export async function incrementViewCount(videoId: number) {
  const db = await getDb(); if (!db) return;
  await db.update(videos).set({ viewCount: sql`viewCount + 1` }).where(eq(videos.id, videoId));
}

// ค้นหาวิดีโอ
export async function searchVideos(query: string, limit = 20) {
  const db = await getDb(); if (!db) return [];
  return await db.select().from(videos)
    .where(and(
      or(like(videos.title, `%${query}%`), like(videos.hashtags, `%${query}%`), like(videos.description, `%${query}%`)),
      eq(videos.isDeleted, false)
    ))
    .orderBy(desc(videos.viewCount)).limit(limit);
}

// ADMIN — ลบวิดีโอ
export async function adminDeleteVideo(videoId: number) {
  const db = await getDb(); if (!db) return;
  await db.update(videos).set({ isDeleted: true, updatedAt: new Date() }).where(eq(videos.id, videoId));
}

// ADMIN — ดูวิดีโอทั้งหมด
export async function adminGetAllVideos(limit = 50, offset = 0) {
  const db = await getDb(); if (!db) return [];
  return await db.select().from(videos).orderBy(desc(videos.createdAt)).limit(limit).offset(offset);
}

// ADMIN — สร้างวิดีโอให้บัญชีปลอม
export async function adminCreateVideoForUser(userId: number, data: { title: string; description?: string; videoUrl: string; thumbnailUrl?: string; hashtags?: string; category?: string }) {
  const db = await getDb(); if (!db) return;
  await db.insert(videos).values({
    userId,
    title: data.title,
    description: data.description || "",
    videoUrl: data.videoUrl,
    thumbnailUrl: data.thumbnailUrl || null,
    hashtags: data.hashtags || "",
    category: data.category || "explore",
    createdAt: new Date(),
    updatedAt: new Date(),
  });
}

// ══════════════════════════════════════════
// LIKES
// ══════════════════════════════════════════
export async function getLikeCount(videoId: number) {
  const db = await getDb(); if (!db) return 0;
  const r = await db.select({ count: sql<number>`COUNT(*)` }).from(likes).where(eq(likes.videoId, videoId));
  return r[0]?.count ?? 0;
}

export async function isVideoLikedByUser(videoId: number, userId: number) {
  const db = await getDb(); if (!db) return false;
  const r = await db.select().from(likes).where(and(eq(likes.videoId, videoId), eq(likes.userId, userId))).limit(1);
  return r.length > 0;
}

export async function addLike(videoId: number, userId: number) {
  const db = await getDb(); if (!db) return;
  await db.insert(likes).values({ videoId, userId, createdAt: new Date() }).onDuplicateKeyUpdate({ set: { createdAt: new Date() } });
  await db.update(videos).set({ likeCount: sql`likeCount + 1` }).where(eq(videos.id, videoId));
}

export async function removeLike(videoId: number, userId: number) {
  const db = await getDb(); if (!db) return;
  await db.delete(likes).where(and(eq(likes.videoId, videoId), eq(likes.userId, userId)));
  await db.update(videos).set({ likeCount: sql`GREATEST(likeCount - 1, 0)` }).where(eq(videos.id, videoId));
}

export async function getUserLikedVideos(userId: number, limit = 20, offset = 0) {
  const db = await getDb(); if (!db) return [];
  return await db.select({ video: videos }).from(likes)
    .innerJoin(videos, eq(likes.videoId, videos.id))
    .where(and(eq(likes.userId, userId), eq(videos.isDeleted, false)))
    .orderBy(desc(likes.createdAt)).limit(limit).offset(offset);
}

// ADMIN — เพิ่มไลค์ให้วิดีโอ
export async function adminAddFakeLikes(videoId: number, count: number) {
  const db = await getDb(); if (!db) return;
  const fakeUsers = await db.select().from(users).where(eq(users.isFake, true)).limit(count);
  for (const fu of fakeUsers) {
    const exists = await isVideoLikedByUser(videoId, fu.id);
    if (!exists) await addLike(videoId, fu.id);
  }
}

// ══════════════════════════════════════════
// COMMENTS
// ══════════════════════════════════════════
export async function getCommentCount(videoId: number) {
  const db = await getDb(); if (!db) return 0;
  const r = await db.select({ count: sql<number>`COUNT(*)` }).from(comments)
    .where(and(eq(comments.videoId, videoId), eq(comments.isDeleted, false)));
  return r[0]?.count ?? 0;
}

export async function getCommentsByVideo(videoId: number, limit = 20, offset = 0) {
  const db = await getDb(); if (!db) return [];
  return await db.select({
    id: comments.id, content: comments.content, createdAt: comments.createdAt,
    userId: comments.userId, parentCommentId: comments.parentCommentId,
    userName: users.name, userProfileImageUrl: users.profileImageUrl, userIsVerified: users.isVerified,
  }).from(comments)
    .innerJoin(users, eq(comments.userId, users.id))
    .where(and(eq(comments.videoId, videoId), isNull(comments.parentCommentId), eq(comments.isDeleted, false)))
    .orderBy(desc(comments.createdAt)).limit(limit).offset(offset);
}

export async function createComment(videoId: number, userId: number, content: string, parentCommentId?: number) {
  const db = await getDb(); if (!db) return;
  await db.insert(comments).values({ videoId, userId, content, parentCommentId: parentCommentId || null, createdAt: new Date(), updatedAt: new Date() });
  await db.update(videos).set({ commentCount: sql`commentCount + 1` }).where(eq(videos.id, videoId));
}

// ══════════════════════════════════════════
// BOOKMARKS
// ══════════════════════════════════════════
export async function isVideoBookmarkedByUser(videoId: number, userId: number) {
  const db = await getDb(); if (!db) return false;
  const r = await db.select().from(bookmarks).where(and(eq(bookmarks.videoId, videoId), eq(bookmarks.userId, userId))).limit(1);
  return r.length > 0;
}

export async function getUserBookmarks(userId: number, limit = 20, offset = 0) {
  const db = await getDb(); if (!db) return [];
  return await db.select({ video: videos }).from(bookmarks)
    .innerJoin(videos, eq(bookmarks.videoId, videos.id))
    .where(and(eq(bookmarks.userId, userId), eq(videos.isDeleted, false)))
    .orderBy(desc(bookmarks.createdAt)).limit(limit).offset(offset);
}

export async function addBookmark(videoId: number, userId: number) {
  const db = await getDb(); if (!db) return;
  await db.insert(bookmarks).values({ videoId, userId, createdAt: new Date() }).onDuplicateKeyUpdate({ set: { createdAt: new Date() } });
  await db.update(videos).set({ bookmarkCount: sql`bookmarkCount + 1` }).where(eq(videos.id, videoId));
}

export async function removeBookmark(videoId: number, userId: number) {
  const db = await getDb(); if (!db) return;
  await db.delete(bookmarks).where(and(eq(bookmarks.videoId, videoId), eq(bookmarks.userId, userId)));
  await db.update(videos).set({ bookmarkCount: sql`GREATEST(bookmarkCount - 1, 0)` }).where(eq(videos.id, videoId));
}

// ══════════════════════════════════════════
// REPOSTS
// ══════════════════════════════════════════
export async function getRepostCount(videoId: number) {
  const db = await getDb(); if (!db) return 0;
  const r = await db.select({ count: sql<number>`COUNT(*)` }).from(reposts).where(eq(reposts.videoId, videoId));
  return r[0]?.count ?? 0;
}

export async function createRepost(videoId: number, userId: number) {
  const db = await getDb(); if (!db) return;
  await db.insert(reposts).values({ videoId, userId, createdAt: new Date() }).onDuplicateKeyUpdate({ set: { createdAt: new Date() } });
  await db.update(videos).set({ repostCount: sql`repostCount + 1` }).where(eq(videos.id, videoId));
}

// ══════════════════════════════════════════
// SHARES
// ══════════════════════════════════════════
export async function createShare(videoId: number, userId: number) {
  const db = await getDb(); if (!db) return;
  await db.insert(shares).values({ videoId, userId, createdAt: new Date() });
  await db.update(videos).set({ shareCount: sql`shareCount + 1` }).where(eq(videos.id, videoId));
}

// ══════════════════════════════════════════
// FOLLOWS
// ══════════════════════════════════════════
export async function getFollowerCount(userId: number) {
  const db = await getDb(); if (!db) return 0;
  const r = await db.select({ count: sql<number>`COUNT(*)` }).from(follows).where(eq(follows.followingId, userId));
  return r[0]?.count ?? 0;
}

export async function getFollowingCount(userId: number) {
  const db = await getDb(); if (!db) return 0;
  const r = await db.select({ count: sql<number>`COUNT(*)` }).from(follows).where(eq(follows.followerId, userId));
  return r[0]?.count ?? 0;
}

export async function isUserFollowing(followerId: number, followingId: number) {
  const db = await getDb(); if (!db) return false;
  const r = await db.select().from(follows).where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId))).limit(1);
  return r.length > 0;
}

export async function addFollow(followerId: number, followingId: number) {
  const db = await getDb(); if (!db) return;
  await db.insert(follows).values({ followerId, followingId, createdAt: new Date() }).onDuplicateKeyUpdate({ set: { createdAt: new Date() } });
  // อัปเดต cache counts
  const [fc, fg] = await Promise.all([getFollowerCount(followingId), getFollowingCount(followerId)]);
  await Promise.all([
    db.update(users).set({ followerCount: fc }).where(eq(users.id, followingId)),
    db.update(users).set({ followingCount: fg }).where(eq(users.id, followerId)),
  ]);
  // แจ้งเตือน milestone 200 คน
  if (fc >= 200 && fc % 100 === 0) {
    await createNotification(followingId, followingId, "milestone", undefined, undefined, `🎉 มีผู้ติดตามครบ ${fc.toLocaleString()} คนแล้ว!`);
  }
}

export async function removeFollow(followerId: number, followingId: number) {
  const db = await getDb(); if (!db) return;
  await db.delete(follows).where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId)));
  const [fc, fg] = await Promise.all([getFollowerCount(followingId), getFollowingCount(followerId)]);
  await Promise.all([
    db.update(users).set({ followerCount: fc }).where(eq(users.id, followingId)),
    db.update(users).set({ followingCount: fg }).where(eq(users.id, followerId)),
  ]);
}

export async function getFollowers(userId: number, limit = 50) {
  const db = await getDb(); if (!db) return [];
  return await db.select({ user: users }).from(follows)
    .innerJoin(users, eq(follows.followerId, users.id))
    .where(eq(follows.followingId, userId)).limit(limit);
}

export async function getFollowing(userId: number, limit = 50) {
  const db = await getDb(); if (!db) return [];
  return await db.select({ user: users }).from(follows)
    .innerJoin(users, eq(follows.followingId, users.id))
    .where(eq(follows.followerId, userId)).limit(limit);
}

// ══════════════════════════════════════════
// NOTIFICATIONS
// ══════════════════════════════════════════
export async function createNotification(
  userId: number, actorId: number,
  type: "like" | "comment" | "follow" | "repost" | "share" | "milestone",
  videoId?: number, commentId?: number, message?: string
) {
  const db = await getDb(); if (!db) return;
  await db.insert(notifications).values({
    userId, actorId, type,
    videoId: videoId || null,
    commentId: commentId || null,
    message: message || null,
    isRead: false, createdAt: new Date(),
  });
}

export async function getNotifications(userId: number) {
  const db = await getDb(); if (!db) return [];
  const r = await db.select({
    id: notifications.id, type: notifications.type, isRead: notifications.isRead,
    createdAt: notifications.createdAt, videoId: notifications.videoId,
    actorId: notifications.actorId, message: notifications.message,
    actorName: users.name, actorProfileImageUrl: users.profileImageUrl,
    actorIsVerified: users.isVerified,
  }).from(notifications)
    .innerJoin(users, eq(notifications.actorId, users.id))
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt)).limit(50);

  return r.map(n => ({
    id: n.id, type: n.type, isRead: n.isRead, createdAt: n.createdAt,
    videoId: n.videoId, message: n.message,
    actor: { id: n.actorId, name: n.actorName, profileImageUrl: n.actorProfileImageUrl, isVerified: n.actorIsVerified },
  }));
}

export async function markNotificationsRead(userId: number) {
  const db = await getDb(); if (!db) return;
  await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, userId));
}

export async function getUnreadNotificationCount(userId: number) {
  const db = await getDb(); if (!db) return 0;
  const r = await db.select({ count: sql<number>`COUNT(*)` }).from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
  return r[0]?.count ?? 0;
}

// ══════════════════════════════════════════
// ADMIN — STATS
// ══════════════════════════════════════════
export async function getAdminStats() {
  const db = await getDb();
  if (!db) return { totalUsers: 0, totalVideos: 0, totalLikes: 0, totalFollows: 0, bannedUsers: 0, fakeUsers: 0 };

  const [users_r, videos_r, likes_r, follows_r, banned_r, fake_r] = await Promise.all([
    db.select({ count: sql<number>`COUNT(*)` }).from(users),
    db.select({ count: sql<number>`COUNT(*)` }).from(videos).where(eq(videos.isDeleted, false)),
    db.select({ count: sql<number>`COUNT(*)` }).from(likes),
    db.select({ count: sql<number>`COUNT(*)` }).from(follows),
    db.select({ count: sql<number>`COUNT(*)` }).from(users).where(eq(users.isBanned, true)),
    db.select({ count: sql<number>`COUNT(*)` }).from(users).where(eq(users.isFake, true)),
  ]);

  return {
    totalUsers: users_r[0]?.count ?? 0,
    totalVideos: videos_r[0]?.count ?? 0,
    totalLikes: likes_r[0]?.count ?? 0,
    totalFollows: follows_r[0]?.count ?? 0,
    bannedUsers: banned_r[0]?.count ?? 0,
    fakeUsers: fake_r[0]?.count ?? 0,
  };
}
