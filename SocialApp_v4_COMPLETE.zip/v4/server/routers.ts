import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

// middleware ตรวจสอบ admin
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "เฉพาะผู้ดูแลระบบเท่านั้น" });
  return next();
});

export const appRouter = router({
  system: systemRouter,

  // ── AUTH ───────────────────────────────────
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const opts = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...opts, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ── VIDEOS ─────────────────────────────────
  videos: router({
    create: protectedProcedure
      .input(z.object({ title: z.string().min(1), description: z.string().optional(), videoUrl: z.string().url(), category: z.enum(["explore","following","recommended"]).default("explore"), hashtags: z.string().optional() }))
      .mutation(async ({ input, ctx }) => {
        await db.createVideo(ctx.user.id, input.title, input.description||"", input.videoUrl, input.category, input.hashtags||"");
        return { success: true };
      }),

    getByCategory: publicProcedure
      .input(z.object({ category: z.enum(["explore","following","recommended"]), limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input }) => db.getVideosByCategory(input.category, input.limit, input.offset)),

    getFollowingVideos: protectedProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input, ctx }) => db.getFollowingVideos(ctx.user.id, input.limit, input.offset)),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        await db.incrementViewCount(input.id);
        return db.getVideoById(input.id);
      }),

    getUserVideos: publicProcedure
      .input(z.object({ userId: z.number(), limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input }) => db.getUserVideos(input.userId, input.limit, input.offset)),

    search: publicProcedure
      .input(z.object({ query: z.string().min(1), limit: z.number().default(20) }))
      .query(async ({ input }) => db.searchVideos(input.query, input.limit)),
  }),

  // ── LIKES ──────────────────────────────────
  likes: router({
    getCount: publicProcedure
      .input(z.object({ videoId: z.number() }))
      .query(async ({ input }) => db.getLikeCount(input.videoId)),

    isLiked: protectedProcedure
      .input(z.object({ videoId: z.number() }))
      .query(async ({ input, ctx }) => db.isVideoLikedByUser(input.videoId, ctx.user.id)),

    toggle: protectedProcedure
      .input(z.object({ videoId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const isLiked = await db.isVideoLikedByUser(input.videoId, ctx.user.id);
        if (isLiked) {
          await db.removeLike(input.videoId, ctx.user.id);
        } else {
          await db.addLike(input.videoId, ctx.user.id);
          const video = await db.getVideoById(input.videoId);
          if (video && video.userId !== ctx.user.id) {
            await db.createNotification(video.userId, ctx.user.id, "like", input.videoId);
          }
        }
        return { success: true, isLiked: !isLiked };
      }),

    getLikedVideos: protectedProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input, ctx }) => db.getUserLikedVideos(ctx.user.id, input.limit, input.offset)),
  }),

  // ── COMMENTS ───────────────────────────────
  comments: router({
    getCount: publicProcedure
      .input(z.object({ videoId: z.number() }))
      .query(async ({ input }) => db.getCommentCount(input.videoId)),

    getByVideo: publicProcedure
      .input(z.object({ videoId: z.number(), limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input }) => db.getCommentsByVideo(input.videoId, input.limit, input.offset)),

    create: protectedProcedure
      .input(z.object({ videoId: z.number(), content: z.string().min(1), parentCommentId: z.number().optional() }))
      .mutation(async ({ input, ctx }) => {
        await db.createComment(input.videoId, ctx.user.id, input.content, input.parentCommentId);
        const video = await db.getVideoById(input.videoId);
        if (video && video.userId !== ctx.user.id) {
          await db.createNotification(video.userId, ctx.user.id, "comment", input.videoId);
        }
        return { success: true };
      }),
  }),

  // ── BOOKMARKS ──────────────────────────────
  bookmarks: router({
    isBookmarked: protectedProcedure
      .input(z.object({ videoId: z.number() }))
      .query(async ({ input, ctx }) => db.isVideoBookmarkedByUser(input.videoId, ctx.user.id)),

    getAll: protectedProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input, ctx }) => db.getUserBookmarks(ctx.user.id, input.limit, input.offset)),

    toggle: protectedProcedure
      .input(z.object({ videoId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const isSaved = await db.isVideoBookmarkedByUser(input.videoId, ctx.user.id);
        if (isSaved) { await db.removeBookmark(input.videoId, ctx.user.id); }
        else { await db.addBookmark(input.videoId, ctx.user.id); }
        return { success: true, isBookmarked: !isSaved };
      }),
  }),

  // ── REPOSTS ────────────────────────────────
  reposts: router({
    getCount: publicProcedure
      .input(z.object({ videoId: z.number() }))
      .query(async ({ input }) => db.getRepostCount(input.videoId)),

    create: protectedProcedure
      .input(z.object({ videoId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.createRepost(input.videoId, ctx.user.id);
        const video = await db.getVideoById(input.videoId);
        if (video && video.userId !== ctx.user.id) {
          await db.createNotification(video.userId, ctx.user.id, "repost", input.videoId);
        }
        return { success: true };
      }),
  }),

  // ── SHARES ─────────────────────────────────
  shares: router({
    create: protectedProcedure
      .input(z.object({ videoId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.createShare(input.videoId, ctx.user.id);
        const video = await db.getVideoById(input.videoId);
        if (video && video.userId !== ctx.user.id) {
          await db.createNotification(video.userId, ctx.user.id, "share", input.videoId);
        }
        return { success: true };
      }),
  }),

  // ── FOLLOWS ────────────────────────────────
  follows: router({
    getFollowerCount: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => db.getFollowerCount(input.userId)),

    getFollowingCount: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => db.getFollowingCount(input.userId)),

    isFollowing: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input, ctx }) => db.isUserFollowing(ctx.user.id, input.userId)),

    toggle: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (input.userId === ctx.user.id) throw new TRPCError({ code: "BAD_REQUEST", message: "ไม่สามารถติดตามตัวเองได้" });
        const isFollowing = await db.isUserFollowing(ctx.user.id, input.userId);
        if (isFollowing) {
          await db.removeFollow(ctx.user.id, input.userId);
        } else {
          await db.addFollow(ctx.user.id, input.userId);
          await db.createNotification(input.userId, ctx.user.id, "follow");
        }
        return { success: true, isFollowing: !isFollowing };
      }),

    getFollowers: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => db.getFollowers(input.userId)),

    getFollowing: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => db.getFollowing(input.userId)),
  }),

  // ── USERS ──────────────────────────────────
  users: router({
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => db.getUserById(input.id)),

    search: publicProcedure
      .input(z.object({ query: z.string().min(1) }))
      .query(async ({ input }) => db.searchUsers(input.query)),

    updateProfile: protectedProcedure
      .input(z.object({ name: z.string().min(1).optional(), bio: z.string().optional(), profileImageUrl: z.string().optional() }))
      .mutation(async ({ input, ctx }) => {
        await db.updateUser(ctx.user.id, input);
        return { success: true };
      }),
  }),

  // ── NOTIFICATIONS ──────────────────────────
  notifications: router({
    getAll: protectedProcedure
      .query(async ({ ctx }) => db.getNotifications(ctx.user.id)),

    markAllRead: protectedProcedure
      .mutation(async ({ ctx }) => { await db.markNotificationsRead(ctx.user.id); return { success: true }; }),

    getUnreadCount: protectedProcedure
      .query(async ({ ctx }) => db.getUnreadNotificationCount(ctx.user.id)),
  }),

  // ══════════════════════════════════════════
  // ADMIN — เฉพาะ role=admin เข้าได้
  // ══════════════════════════════════════════
  admin: router({
    // ดู stats ภาพรวม
    getStats: adminProcedure
      .query(async () => db.getAdminStats()),

    // ── จัดการผู้ใช้ ──
    getAllUsers: adminProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input }) => db.getAllUsers(input.limit, input.offset)),

    setVerified: adminProcedure
      .input(z.object({ userId: z.number(), isVerified: z.boolean() }))
      .mutation(async ({ input }) => { await db.setUserVerified(input.userId, input.isVerified); return { success: true }; }),

    setBanned: adminProcedure
      .input(z.object({ userId: z.number(), isBanned: z.boolean() }))
      .mutation(async ({ input }) => { await db.setUserBanned(input.userId, input.isBanned); return { success: true }; }),

    deleteUser: adminProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input }) => { await db.deleteUser(input.userId); return { success: true }; }),

    // ── บัญชีปลอม ──
    createFakeUser: adminProcedure
      .input(z.object({ name: z.string().min(1), bio: z.string().optional(), profileImageUrl: z.string().optional() }))
      .mutation(async ({ input }) => db.createFakeUser(input)),

    addFakeFollowers: adminProcedure
      .input(z.object({ targetUserId: z.number(), count: z.number().min(1).max(500) }))
      .mutation(async ({ input }) => {
        const added = await db.adminAddFakeFollowers(input.targetUserId, input.count);
        return { success: true, added };
      }),

    addFakeLikes: adminProcedure
      .input(z.object({ videoId: z.number(), count: z.number().min(1).max(500) }))
      .mutation(async ({ input }) => { await db.adminAddFakeLikes(input.videoId, input.count); return { success: true }; }),

    // ── จัดการวิดีโอ ──
    getAllVideos: adminProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input }) => db.adminGetAllVideos(input.limit, input.offset)),

    deleteVideo: adminProcedure
      .input(z.object({ videoId: z.number() }))
      .mutation(async ({ input }) => { await db.adminDeleteVideo(input.videoId); return { success: true }; }),

    createVideoForUser: adminProcedure
      .input(z.object({
        userId: z.number(),
        title: z.string().min(1),
        description: z.string().optional(),
        videoUrl: z.string().url(),
        thumbnailUrl: z.string().optional(),
        hashtags: z.string().optional(),
        category: z.enum(["explore","following","recommended"]).default("explore"),
      }))
      .mutation(async ({ input }) => { await db.adminCreateVideoForUser(input.userId, input); return { success: true }; }),
  }),
});

export type AppRouter = typeof appRouter;
